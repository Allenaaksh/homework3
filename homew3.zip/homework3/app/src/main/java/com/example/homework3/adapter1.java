package com.example.homework3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class adapter1 extends RecyclerView.Adapter<adapter1.adapter1ViewHolder> {
    private List<Breeds> breedsList;

    public void setData(List<Breeds> breedsList) {
        this.breedsList = breedsList;
    }

    @NonNull
    @Override
    public adapter1.adapter1ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.cat, parent, false);

        adapter1ViewHolder breedsViewHolder = new adapter1ViewHolder(view);
        return breedsViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull adapter1.adapter1ViewHolder holder, int position) {

   final Breeds breeds = breedsList.get(position);
        //System.out.println(breedsList.toArray());
        holder.name.setText(breeds.getName());
        holder.temperament.setText(breeds.getTemperament());
        holder.life_span.setText(breeds.getLife_span());
        holder.wikipedia_url.setText(breeds.getWikipedia_url());
   //holder.bind(breeds);


    }

    @Override
    public int getItemCount() {
        return breedsList.size();
    }

    public static class adapter1ViewHolder extends RecyclerView.ViewHolder  {
        public TextView name;
        public View view;
        public TextView temperament;
        public TextView life_span;
        public TextView wikipedia_url;
        public adapter1ViewHolder(@NonNull View v) {
            super(v);
            view = v;
            name = v.findViewById(R.id.catnamee);
            temperament = v.findViewById(R.id.Temperament);
            life_span = v.findViewById(R.id.Life_span);
            wikipedia_url = v.findViewById(R.id.Wikipedia_url);

        }
        public void bind(final Breeds breeds){
           // System.out.println("dwefewf"+breeds.getName());
            name.setText(breeds.getName());
            temperament.setText(breeds.getTemperament());
            life_span.setText(breeds.getLife_span());
            wikipedia_url.setText(breeds.getWikipedia_url());


        }
    }


}


