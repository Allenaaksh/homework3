package com.example.homework3;

public class weight {

        private String imperical;
        private String metric ;

        public String getImperical() {
            return imperical;
        }

        public void setImperical(String imperical) {
            this.imperical = imperical;
        }

        public String getMetric() {
            return metric;
        }

        public void setMetric(String metric) {
            this.metric = metric;
        }
    }



