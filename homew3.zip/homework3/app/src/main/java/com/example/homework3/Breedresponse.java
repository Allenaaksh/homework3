package com.example.homework3;

import java.util.ArrayList;
import java.util.List;

public class Breedresponse {

    public String name;

    public List<Breeds> result;
}
