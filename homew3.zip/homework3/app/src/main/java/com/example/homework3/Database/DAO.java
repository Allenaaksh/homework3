//package com.example.homework3.Database;
//
//
//import androidx.room.Dao;
//import androidx.room.Insert;
//import androidx.room.Query;
//
//import com.example.homework3.Breeds;
//
//import java.util.List;
//
//@Dao
//public interface DAO {
//    @Query("SELECT * FROM Breeds")
//    List<Breeds> getName();
//
//
//    @Query("SELECT COUNT(*) from Breeds")
//    int getCount();
//
//    @Query("SELECT * FROM Breeds WHERE id =:id")
//    Breeds getcatbyid(String id);
//
//    @Insert
//    void insert(Breeds breeds);
//}
